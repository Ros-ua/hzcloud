﻿import datetime
import asyncio
from telethon import TelegramClient, sync, events
import json
from threading import Timer
from time import sleep
from RF_class import RF
from addons import qHash

print("load json")
with open("settings.json", "r") as read_file :
    jsdata = json.load(read_file)
my_id = jsdata["my_id"]

vex_bot_id = 1033007754

async def check(message) :
    # print(event)
    try :
        from_id = message.from_id.user_id
    except :
        from_id = 0
#    print(message)

    chatFrom = message.peer_id
    chat_id = 0
    if hasattr(chatFrom, 'user_id') :
        chat_id = message.peer_id.user_id
    elif hasattr(chatFrom, 'channel_id') :
        chat_id = message.peer_id.channel_id

    if (chat_id == my_id) :
        bool_status = False
        if ("_on" in message.message) :
            bool_status = True
        if ("_off" in message.message) :
            bool_status = False
        if ("/rf_user" in message.message) :
            RF.is_run = bool_status
            jsdata["user_RF"] = RF.is_run
            await client.send_message(chat_id, "RF : " + str(RF.is_run))
        if ("/userbot_status" in message.message) :
            await client.send_message(chat_id, start_text_sms \
                                      + "\n  RF : " + str(RF.is_run)
                                      )
        if ("rf_ask" in message.message) :
            await client.send_message(chat_id, f"rf:\nin {RF.is_in_caves}\nhil {RF.is_has_hil}\nres {RF.is_has_res}")
        
        if ("/userbot_stop" in message.message) :
            client.disconnect()
        return

    if (from_id == my_id) :
        return
    
    if (RF.isIdCompare(chat_id)) :
        await RF.msg_parce(message)
        return

    if (RF.isCaveLeaderIdCompare(chat_id)) :
        if (RF.is_run) :
            await RF.cmd(message)
        return

api_id = jsdata["api_id"]
api_hash = jsdata["api_hash"]

client: TelegramClient = TelegramClient("ros app", api_id, api_hash, system_version="4.16.30-rosCustom")

@client.on(events.NewMessage)
async def normal_handler(event) :
    await check(event.message)

@client.on(events.MessageEdited)
async def normal_handler(event) :
    await check(event.message)

client.start()

RF = RF(client)
RF.is_run = jsdata["user_RF"]
start_text_sms = "Юзер-бот запущен " + datetime.datetime.now().strftime("%Y.%m.%d - %H:%M:%S")

loop = client.loop
client.run_until_disconnected()

print("save json")
with open("settings.json", "w") as write_file :
    json.dump(jsdata, write_file, indent=2)
