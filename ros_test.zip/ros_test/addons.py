from ctypes import c_uint32

def qHash(string, seed = 0) :
    h = c_uint32(seed)
    for i in range(0, len(string)) :
        # print(h, ord(string[i]), string[i])
        h = c_uint32(31*h.value + ord(string[i]))
    return h.value
